﻿namespace THS.Windows
{
    partial class HS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonHeroEnemy = new System.Windows.Forms.Button();
            this.groupBoxBoardEnemyNumber = new System.Windows.Forms.GroupBox();
            this.buttonBoardEnemyNumber7 = new System.Windows.Forms.Button();
            this.buttonBoardEnemyNumber6 = new System.Windows.Forms.Button();
            this.buttonBoardEnemyNumber5 = new System.Windows.Forms.Button();
            this.buttonBoardEnemyNumber4 = new System.Windows.Forms.Button();
            this.buttonBoardEnemyNumber3 = new System.Windows.Forms.Button();
            this.buttonBoardEnemyNumber2 = new System.Windows.Forms.Button();
            this.buttonBoardEnemyNumber1 = new System.Windows.Forms.Button();
            this.groupBoxBoardEnemySize = new System.Windows.Forms.GroupBox();
            this.buttonBoardEnemySize7 = new System.Windows.Forms.Button();
            this.buttonBoardEnemySize6 = new System.Windows.Forms.Button();
            this.buttonBoardEnemySize5 = new System.Windows.Forms.Button();
            this.buttonBoardEnemySize4 = new System.Windows.Forms.Button();
            this.buttonBoardEnemySize3 = new System.Windows.Forms.Button();
            this.buttonBoardEnemySize2 = new System.Windows.Forms.Button();
            this.buttonBoardEnemySize1 = new System.Windows.Forms.Button();
            this.groupBoxBoardNumber = new System.Windows.Forms.GroupBox();
            this.buttonBoardNumber7 = new System.Windows.Forms.Button();
            this.buttonBoardNumber6 = new System.Windows.Forms.Button();
            this.buttonBoardNumber5 = new System.Windows.Forms.Button();
            this.buttonBoardNumber4 = new System.Windows.Forms.Button();
            this.buttonBoardNumber3 = new System.Windows.Forms.Button();
            this.buttonBoardNumber2 = new System.Windows.Forms.Button();
            this.buttonBoardNumber1 = new System.Windows.Forms.Button();
            this.groupBoxHandNumber = new System.Windows.Forms.GroupBox();
            this.buttonHandNumber10 = new System.Windows.Forms.Button();
            this.buttonHandNumber9 = new System.Windows.Forms.Button();
            this.buttonHandNumber8 = new System.Windows.Forms.Button();
            this.buttonHandNumber7 = new System.Windows.Forms.Button();
            this.buttonHandNumber6 = new System.Windows.Forms.Button();
            this.buttonHandNumber5 = new System.Windows.Forms.Button();
            this.buttonHandNumber4 = new System.Windows.Forms.Button();
            this.buttonHandNumber3 = new System.Windows.Forms.Button();
            this.buttonHandNumber2 = new System.Windows.Forms.Button();
            this.buttonHandNumber1 = new System.Windows.Forms.Button();
            this.groupBoxHandSize = new System.Windows.Forms.GroupBox();
            this.buttonHandSize10 = new System.Windows.Forms.Button();
            this.buttonHandSize9 = new System.Windows.Forms.Button();
            this.buttonHandSize8 = new System.Windows.Forms.Button();
            this.buttonHandSize7 = new System.Windows.Forms.Button();
            this.buttonHandSize6 = new System.Windows.Forms.Button();
            this.buttonHandSize5 = new System.Windows.Forms.Button();
            this.buttonHandSize4 = new System.Windows.Forms.Button();
            this.buttonHandSize3 = new System.Windows.Forms.Button();
            this.buttonHandSize2 = new System.Windows.Forms.Button();
            this.buttonHandSize1 = new System.Windows.Forms.Button();
            this.groupBoxBoardSize = new System.Windows.Forms.GroupBox();
            this.buttonBoardSize7 = new System.Windows.Forms.Button();
            this.buttonBoardSize6 = new System.Windows.Forms.Button();
            this.buttonBoardSize5 = new System.Windows.Forms.Button();
            this.buttonBoardSize4 = new System.Windows.Forms.Button();
            this.buttonBoardSize3 = new System.Windows.Forms.Button();
            this.buttonBoardSize2 = new System.Windows.Forms.Button();
            this.buttonBoardSize1 = new System.Windows.Forms.Button();
            this.buttonHero = new System.Windows.Forms.Button();
            this.buttonPlay = new System.Windows.Forms.Button();
            this.buttonPlayOn = new System.Windows.Forms.Button();
            this.buttonAttack = new System.Windows.Forms.Button();
            this.buttonPower = new System.Windows.Forms.Button();
            this.buttonEnd = new System.Windows.Forms.Button();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.buttonReset = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.buttonConnect = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.groupBoxBoardEnemyNumber.SuspendLayout();
            this.groupBoxBoardEnemySize.SuspendLayout();
            this.groupBoxBoardNumber.SuspendLayout();
            this.groupBoxHandNumber.SuspendLayout();
            this.groupBoxHandSize.SuspendLayout();
            this.groupBoxBoardSize.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.buttonHeroEnemy);
            this.panel1.Controls.Add(this.groupBoxBoardEnemyNumber);
            this.panel1.Controls.Add(this.groupBoxBoardEnemySize);
            this.panel1.Controls.Add(this.groupBoxBoardNumber);
            this.panel1.Controls.Add(this.groupBoxHandNumber);
            this.panel1.Controls.Add(this.groupBoxHandSize);
            this.panel1.Controls.Add(this.groupBoxBoardSize);
            this.panel1.Controls.Add(this.buttonHero);
            this.panel1.Location = new System.Drawing.Point(107, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(540, 578);
            this.panel1.TabIndex = 0;
            // 
            // buttonHeroEnemy
            // 
            this.buttonHeroEnemy.Location = new System.Drawing.Point(3, 6);
            this.buttonHeroEnemy.Name = "buttonHeroEnemy";
            this.buttonHeroEnemy.Size = new System.Drawing.Size(494, 36);
            this.buttonHeroEnemy.TabIndex = 18;
            this.buttonHeroEnemy.Text = "Enemy Hero";
            this.buttonHeroEnemy.UseVisualStyleBackColor = true;
            this.buttonHeroEnemy.MouseDown += new System.Windows.Forms.MouseEventHandler(this.buttonHeroEnemy_MouseClick);
            // 
            // groupBoxBoardEnemyNumber
            // 
            this.groupBoxBoardEnemyNumber.Controls.Add(this.buttonBoardEnemyNumber7);
            this.groupBoxBoardEnemyNumber.Controls.Add(this.buttonBoardEnemyNumber6);
            this.groupBoxBoardEnemyNumber.Controls.Add(this.buttonBoardEnemyNumber5);
            this.groupBoxBoardEnemyNumber.Controls.Add(this.buttonBoardEnemyNumber4);
            this.groupBoxBoardEnemyNumber.Controls.Add(this.buttonBoardEnemyNumber3);
            this.groupBoxBoardEnemyNumber.Controls.Add(this.buttonBoardEnemyNumber2);
            this.groupBoxBoardEnemyNumber.Controls.Add(this.buttonBoardEnemyNumber1);
            this.groupBoxBoardEnemyNumber.Location = new System.Drawing.Point(88, 48);
            this.groupBoxBoardEnemyNumber.Name = "groupBoxBoardEnemyNumber";
            this.groupBoxBoardEnemyNumber.Size = new System.Drawing.Size(351, 70);
            this.groupBoxBoardEnemyNumber.TabIndex = 15;
            this.groupBoxBoardEnemyNumber.TabStop = false;
            this.groupBoxBoardEnemyNumber.Text = "Enemy Board Number";
            // 
            // buttonBoardEnemyNumber7
            // 
            this.buttonBoardEnemyNumber7.Location = new System.Drawing.Point(303, 18);
            this.buttonBoardEnemyNumber7.Name = "buttonBoardEnemyNumber7";
            this.buttonBoardEnemyNumber7.Size = new System.Drawing.Size(44, 44);
            this.buttonBoardEnemyNumber7.TabIndex = 12;
            this.buttonBoardEnemyNumber7.Text = "7";
            this.buttonBoardEnemyNumber7.UseVisualStyleBackColor = true;
            this.buttonBoardEnemyNumber7.Click += new System.EventHandler(this.buttonBoardEnemyNumber_Click);
            // 
            // buttonBoardEnemyNumber6
            // 
            this.buttonBoardEnemyNumber6.Location = new System.Drawing.Point(253, 18);
            this.buttonBoardEnemyNumber6.Name = "buttonBoardEnemyNumber6";
            this.buttonBoardEnemyNumber6.Size = new System.Drawing.Size(44, 44);
            this.buttonBoardEnemyNumber6.TabIndex = 11;
            this.buttonBoardEnemyNumber6.Text = "6";
            this.buttonBoardEnemyNumber6.UseVisualStyleBackColor = true;
            this.buttonBoardEnemyNumber6.Click += new System.EventHandler(this.buttonBoardEnemyNumber_Click);
            // 
            // buttonBoardEnemyNumber5
            // 
            this.buttonBoardEnemyNumber5.Location = new System.Drawing.Point(203, 17);
            this.buttonBoardEnemyNumber5.Name = "buttonBoardEnemyNumber5";
            this.buttonBoardEnemyNumber5.Size = new System.Drawing.Size(44, 44);
            this.buttonBoardEnemyNumber5.TabIndex = 10;
            this.buttonBoardEnemyNumber5.Text = "5";
            this.buttonBoardEnemyNumber5.UseVisualStyleBackColor = true;
            this.buttonBoardEnemyNumber5.Click += new System.EventHandler(this.buttonBoardEnemyNumber_Click);
            // 
            // buttonBoardEnemyNumber4
            // 
            this.buttonBoardEnemyNumber4.Location = new System.Drawing.Point(153, 17);
            this.buttonBoardEnemyNumber4.Name = "buttonBoardEnemyNumber4";
            this.buttonBoardEnemyNumber4.Size = new System.Drawing.Size(44, 44);
            this.buttonBoardEnemyNumber4.TabIndex = 9;
            this.buttonBoardEnemyNumber4.Text = "4";
            this.buttonBoardEnemyNumber4.UseVisualStyleBackColor = true;
            this.buttonBoardEnemyNumber4.Click += new System.EventHandler(this.buttonBoardEnemyNumber_Click);
            // 
            // buttonBoardEnemyNumber3
            // 
            this.buttonBoardEnemyNumber3.Location = new System.Drawing.Point(103, 17);
            this.buttonBoardEnemyNumber3.Name = "buttonBoardEnemyNumber3";
            this.buttonBoardEnemyNumber3.Size = new System.Drawing.Size(44, 44);
            this.buttonBoardEnemyNumber3.TabIndex = 8;
            this.buttonBoardEnemyNumber3.Text = "3";
            this.buttonBoardEnemyNumber3.UseVisualStyleBackColor = true;
            this.buttonBoardEnemyNumber3.Click += new System.EventHandler(this.buttonBoardEnemyNumber_Click);
            // 
            // buttonBoardEnemyNumber2
            // 
            this.buttonBoardEnemyNumber2.Location = new System.Drawing.Point(53, 18);
            this.buttonBoardEnemyNumber2.Name = "buttonBoardEnemyNumber2";
            this.buttonBoardEnemyNumber2.Size = new System.Drawing.Size(44, 44);
            this.buttonBoardEnemyNumber2.TabIndex = 7;
            this.buttonBoardEnemyNumber2.Text = "2";
            this.buttonBoardEnemyNumber2.UseVisualStyleBackColor = true;
            this.buttonBoardEnemyNumber2.Click += new System.EventHandler(this.buttonBoardEnemyNumber_Click);
            // 
            // buttonBoardEnemyNumber1
            // 
            this.buttonBoardEnemyNumber1.Location = new System.Drawing.Point(3, 18);
            this.buttonBoardEnemyNumber1.Name = "buttonBoardEnemyNumber1";
            this.buttonBoardEnemyNumber1.Size = new System.Drawing.Size(44, 44);
            this.buttonBoardEnemyNumber1.TabIndex = 6;
            this.buttonBoardEnemyNumber1.Text = "1";
            this.buttonBoardEnemyNumber1.UseVisualStyleBackColor = true;
            this.buttonBoardEnemyNumber1.Click += new System.EventHandler(this.buttonBoardEnemyNumber_Click);
            // 
            // groupBoxBoardEnemySize
            // 
            this.groupBoxBoardEnemySize.Controls.Add(this.buttonBoardEnemySize7);
            this.groupBoxBoardEnemySize.Controls.Add(this.buttonBoardEnemySize6);
            this.groupBoxBoardEnemySize.Controls.Add(this.buttonBoardEnemySize5);
            this.groupBoxBoardEnemySize.Controls.Add(this.buttonBoardEnemySize4);
            this.groupBoxBoardEnemySize.Controls.Add(this.buttonBoardEnemySize3);
            this.groupBoxBoardEnemySize.Controls.Add(this.buttonBoardEnemySize2);
            this.groupBoxBoardEnemySize.Controls.Add(this.buttonBoardEnemySize1);
            this.groupBoxBoardEnemySize.Location = new System.Drawing.Point(88, 124);
            this.groupBoxBoardEnemySize.Name = "groupBoxBoardEnemySize";
            this.groupBoxBoardEnemySize.Size = new System.Drawing.Size(351, 70);
            this.groupBoxBoardEnemySize.TabIndex = 14;
            this.groupBoxBoardEnemySize.TabStop = false;
            this.groupBoxBoardEnemySize.Text = "Enemy Board Size";
            // 
            // buttonBoardEnemySize7
            // 
            this.buttonBoardEnemySize7.Location = new System.Drawing.Point(303, 18);
            this.buttonBoardEnemySize7.Name = "buttonBoardEnemySize7";
            this.buttonBoardEnemySize7.Size = new System.Drawing.Size(44, 44);
            this.buttonBoardEnemySize7.TabIndex = 12;
            this.buttonBoardEnemySize7.Text = "7";
            this.buttonBoardEnemySize7.UseVisualStyleBackColor = true;
            this.buttonBoardEnemySize7.Click += new System.EventHandler(this.buttonBoardEnemySize_Click);
            // 
            // buttonBoardEnemySize6
            // 
            this.buttonBoardEnemySize6.Location = new System.Drawing.Point(253, 18);
            this.buttonBoardEnemySize6.Name = "buttonBoardEnemySize6";
            this.buttonBoardEnemySize6.Size = new System.Drawing.Size(44, 44);
            this.buttonBoardEnemySize6.TabIndex = 11;
            this.buttonBoardEnemySize6.Text = "6";
            this.buttonBoardEnemySize6.UseVisualStyleBackColor = true;
            this.buttonBoardEnemySize6.Click += new System.EventHandler(this.buttonBoardEnemySize_Click);
            // 
            // buttonBoardEnemySize5
            // 
            this.buttonBoardEnemySize5.Location = new System.Drawing.Point(203, 17);
            this.buttonBoardEnemySize5.Name = "buttonBoardEnemySize5";
            this.buttonBoardEnemySize5.Size = new System.Drawing.Size(44, 44);
            this.buttonBoardEnemySize5.TabIndex = 10;
            this.buttonBoardEnemySize5.Text = "5";
            this.buttonBoardEnemySize5.UseVisualStyleBackColor = true;
            this.buttonBoardEnemySize5.Click += new System.EventHandler(this.buttonBoardEnemySize_Click);
            // 
            // buttonBoardEnemySize4
            // 
            this.buttonBoardEnemySize4.Location = new System.Drawing.Point(153, 17);
            this.buttonBoardEnemySize4.Name = "buttonBoardEnemySize4";
            this.buttonBoardEnemySize4.Size = new System.Drawing.Size(44, 44);
            this.buttonBoardEnemySize4.TabIndex = 9;
            this.buttonBoardEnemySize4.Text = "4";
            this.buttonBoardEnemySize4.UseVisualStyleBackColor = true;
            this.buttonBoardEnemySize4.Click += new System.EventHandler(this.buttonBoardEnemySize_Click);
            // 
            // buttonBoardEnemySize3
            // 
            this.buttonBoardEnemySize3.Location = new System.Drawing.Point(103, 17);
            this.buttonBoardEnemySize3.Name = "buttonBoardEnemySize3";
            this.buttonBoardEnemySize3.Size = new System.Drawing.Size(44, 44);
            this.buttonBoardEnemySize3.TabIndex = 8;
            this.buttonBoardEnemySize3.Text = "3";
            this.buttonBoardEnemySize3.UseVisualStyleBackColor = true;
            this.buttonBoardEnemySize3.Click += new System.EventHandler(this.buttonBoardEnemySize_Click);
            // 
            // buttonBoardEnemySize2
            // 
            this.buttonBoardEnemySize2.Location = new System.Drawing.Point(53, 18);
            this.buttonBoardEnemySize2.Name = "buttonBoardEnemySize2";
            this.buttonBoardEnemySize2.Size = new System.Drawing.Size(44, 44);
            this.buttonBoardEnemySize2.TabIndex = 7;
            this.buttonBoardEnemySize2.Text = "2";
            this.buttonBoardEnemySize2.UseVisualStyleBackColor = true;
            this.buttonBoardEnemySize2.Click += new System.EventHandler(this.buttonBoardEnemySize_Click);
            // 
            // buttonBoardEnemySize1
            // 
            this.buttonBoardEnemySize1.Location = new System.Drawing.Point(3, 18);
            this.buttonBoardEnemySize1.Name = "buttonBoardEnemySize1";
            this.buttonBoardEnemySize1.Size = new System.Drawing.Size(44, 44);
            this.buttonBoardEnemySize1.TabIndex = 6;
            this.buttonBoardEnemySize1.Text = "1";
            this.buttonBoardEnemySize1.UseVisualStyleBackColor = true;
            this.buttonBoardEnemySize1.Click += new System.EventHandler(this.buttonBoardEnemySize_Click);
            // 
            // groupBoxBoardNumber
            // 
            this.groupBoxBoardNumber.Controls.Add(this.buttonBoardNumber7);
            this.groupBoxBoardNumber.Controls.Add(this.buttonBoardNumber6);
            this.groupBoxBoardNumber.Controls.Add(this.buttonBoardNumber5);
            this.groupBoxBoardNumber.Controls.Add(this.buttonBoardNumber4);
            this.groupBoxBoardNumber.Controls.Add(this.buttonBoardNumber3);
            this.groupBoxBoardNumber.Controls.Add(this.buttonBoardNumber2);
            this.groupBoxBoardNumber.Controls.Add(this.buttonBoardNumber1);
            this.groupBoxBoardNumber.Location = new System.Drawing.Point(88, 200);
            this.groupBoxBoardNumber.Name = "groupBoxBoardNumber";
            this.groupBoxBoardNumber.Size = new System.Drawing.Size(351, 70);
            this.groupBoxBoardNumber.TabIndex = 13;
            this.groupBoxBoardNumber.TabStop = false;
            this.groupBoxBoardNumber.Text = "Board Number";
            // 
            // buttonBoardNumber7
            // 
            this.buttonBoardNumber7.Location = new System.Drawing.Point(303, 18);
            this.buttonBoardNumber7.Name = "buttonBoardNumber7";
            this.buttonBoardNumber7.Size = new System.Drawing.Size(44, 44);
            this.buttonBoardNumber7.TabIndex = 12;
            this.buttonBoardNumber7.Text = "7";
            this.buttonBoardNumber7.UseVisualStyleBackColor = true;
            this.buttonBoardNumber7.Click += new System.EventHandler(this.buttonBoardNumber_Click);
            // 
            // buttonBoardNumber6
            // 
            this.buttonBoardNumber6.Location = new System.Drawing.Point(253, 18);
            this.buttonBoardNumber6.Name = "buttonBoardNumber6";
            this.buttonBoardNumber6.Size = new System.Drawing.Size(44, 44);
            this.buttonBoardNumber6.TabIndex = 11;
            this.buttonBoardNumber6.Text = "6";
            this.buttonBoardNumber6.UseVisualStyleBackColor = true;
            this.buttonBoardNumber6.Click += new System.EventHandler(this.buttonBoardNumber_Click);
            // 
            // buttonBoardNumber5
            // 
            this.buttonBoardNumber5.Location = new System.Drawing.Point(203, 17);
            this.buttonBoardNumber5.Name = "buttonBoardNumber5";
            this.buttonBoardNumber5.Size = new System.Drawing.Size(44, 44);
            this.buttonBoardNumber5.TabIndex = 10;
            this.buttonBoardNumber5.Text = "5";
            this.buttonBoardNumber5.UseVisualStyleBackColor = true;
            this.buttonBoardNumber5.Click += new System.EventHandler(this.buttonBoardNumber_Click);
            // 
            // buttonBoardNumber4
            // 
            this.buttonBoardNumber4.Location = new System.Drawing.Point(153, 17);
            this.buttonBoardNumber4.Name = "buttonBoardNumber4";
            this.buttonBoardNumber4.Size = new System.Drawing.Size(44, 44);
            this.buttonBoardNumber4.TabIndex = 9;
            this.buttonBoardNumber4.Text = "4";
            this.buttonBoardNumber4.UseVisualStyleBackColor = true;
            this.buttonBoardNumber4.Click += new System.EventHandler(this.buttonBoardNumber_Click);
            // 
            // buttonBoardNumber3
            // 
            this.buttonBoardNumber3.Location = new System.Drawing.Point(103, 17);
            this.buttonBoardNumber3.Name = "buttonBoardNumber3";
            this.buttonBoardNumber3.Size = new System.Drawing.Size(44, 44);
            this.buttonBoardNumber3.TabIndex = 8;
            this.buttonBoardNumber3.Text = "3";
            this.buttonBoardNumber3.UseVisualStyleBackColor = true;
            this.buttonBoardNumber3.Click += new System.EventHandler(this.buttonBoardNumber_Click);
            // 
            // buttonBoardNumber2
            // 
            this.buttonBoardNumber2.Location = new System.Drawing.Point(53, 18);
            this.buttonBoardNumber2.Name = "buttonBoardNumber2";
            this.buttonBoardNumber2.Size = new System.Drawing.Size(44, 44);
            this.buttonBoardNumber2.TabIndex = 7;
            this.buttonBoardNumber2.Text = "2";
            this.buttonBoardNumber2.UseVisualStyleBackColor = true;
            this.buttonBoardNumber2.Click += new System.EventHandler(this.buttonBoardNumber_Click);
            // 
            // buttonBoardNumber1
            // 
            this.buttonBoardNumber1.Location = new System.Drawing.Point(3, 18);
            this.buttonBoardNumber1.Name = "buttonBoardNumber1";
            this.buttonBoardNumber1.Size = new System.Drawing.Size(44, 44);
            this.buttonBoardNumber1.TabIndex = 6;
            this.buttonBoardNumber1.Text = "1";
            this.buttonBoardNumber1.UseVisualStyleBackColor = true;
            this.buttonBoardNumber1.Click += new System.EventHandler(this.buttonBoardNumber_Click);
            // 
            // groupBoxHandNumber
            // 
            this.groupBoxHandNumber.Controls.Add(this.buttonHandNumber10);
            this.groupBoxHandNumber.Controls.Add(this.buttonHandNumber9);
            this.groupBoxHandNumber.Controls.Add(this.buttonHandNumber8);
            this.groupBoxHandNumber.Controls.Add(this.buttonHandNumber7);
            this.groupBoxHandNumber.Controls.Add(this.buttonHandNumber6);
            this.groupBoxHandNumber.Controls.Add(this.buttonHandNumber5);
            this.groupBoxHandNumber.Controls.Add(this.buttonHandNumber4);
            this.groupBoxHandNumber.Controls.Add(this.buttonHandNumber3);
            this.groupBoxHandNumber.Controls.Add(this.buttonHandNumber2);
            this.groupBoxHandNumber.Controls.Add(this.buttonHandNumber1);
            this.groupBoxHandNumber.Location = new System.Drawing.Point(19, 394);
            this.groupBoxHandNumber.Name = "groupBoxHandNumber";
            this.groupBoxHandNumber.Size = new System.Drawing.Size(500, 70);
            this.groupBoxHandNumber.TabIndex = 17;
            this.groupBoxHandNumber.TabStop = false;
            this.groupBoxHandNumber.Text = "Hand Number";
            // 
            // buttonHandNumber10
            // 
            this.buttonHandNumber10.Location = new System.Drawing.Point(453, 18);
            this.buttonHandNumber10.Name = "buttonHandNumber10";
            this.buttonHandNumber10.Size = new System.Drawing.Size(44, 44);
            this.buttonHandNumber10.TabIndex = 15;
            this.buttonHandNumber10.Text = "10";
            this.buttonHandNumber10.UseVisualStyleBackColor = true;
            this.buttonHandNumber10.Click += new System.EventHandler(this.buttonHandNumber_Click);
            // 
            // buttonHandNumber9
            // 
            this.buttonHandNumber9.Location = new System.Drawing.Point(403, 18);
            this.buttonHandNumber9.Name = "buttonHandNumber9";
            this.buttonHandNumber9.Size = new System.Drawing.Size(44, 44);
            this.buttonHandNumber9.TabIndex = 14;
            this.buttonHandNumber9.Text = "9";
            this.buttonHandNumber9.UseVisualStyleBackColor = true;
            this.buttonHandNumber9.Click += new System.EventHandler(this.buttonHandNumber_Click);
            // 
            // buttonHandNumber8
            // 
            this.buttonHandNumber8.Location = new System.Drawing.Point(353, 18);
            this.buttonHandNumber8.Name = "buttonHandNumber8";
            this.buttonHandNumber8.Size = new System.Drawing.Size(44, 44);
            this.buttonHandNumber8.TabIndex = 13;
            this.buttonHandNumber8.Text = "8";
            this.buttonHandNumber8.UseVisualStyleBackColor = true;
            this.buttonHandNumber8.Click += new System.EventHandler(this.buttonHandNumber_Click);
            // 
            // buttonHandNumber7
            // 
            this.buttonHandNumber7.Location = new System.Drawing.Point(303, 18);
            this.buttonHandNumber7.Name = "buttonHandNumber7";
            this.buttonHandNumber7.Size = new System.Drawing.Size(44, 44);
            this.buttonHandNumber7.TabIndex = 12;
            this.buttonHandNumber7.Text = "7";
            this.buttonHandNumber7.UseVisualStyleBackColor = true;
            this.buttonHandNumber7.Click += new System.EventHandler(this.buttonHandNumber_Click);
            // 
            // buttonHandNumber6
            // 
            this.buttonHandNumber6.Location = new System.Drawing.Point(253, 18);
            this.buttonHandNumber6.Name = "buttonHandNumber6";
            this.buttonHandNumber6.Size = new System.Drawing.Size(44, 44);
            this.buttonHandNumber6.TabIndex = 11;
            this.buttonHandNumber6.Text = "6";
            this.buttonHandNumber6.UseVisualStyleBackColor = true;
            this.buttonHandNumber6.Click += new System.EventHandler(this.buttonHandNumber_Click);
            // 
            // buttonHandNumber5
            // 
            this.buttonHandNumber5.Location = new System.Drawing.Point(203, 18);
            this.buttonHandNumber5.Name = "buttonHandNumber5";
            this.buttonHandNumber5.Size = new System.Drawing.Size(44, 44);
            this.buttonHandNumber5.TabIndex = 10;
            this.buttonHandNumber5.Text = "5";
            this.buttonHandNumber5.UseVisualStyleBackColor = true;
            this.buttonHandNumber5.Click += new System.EventHandler(this.buttonHandNumber_Click);
            // 
            // buttonHandNumber4
            // 
            this.buttonHandNumber4.Location = new System.Drawing.Point(153, 18);
            this.buttonHandNumber4.Name = "buttonHandNumber4";
            this.buttonHandNumber4.Size = new System.Drawing.Size(44, 44);
            this.buttonHandNumber4.TabIndex = 9;
            this.buttonHandNumber4.Text = "4";
            this.buttonHandNumber4.UseVisualStyleBackColor = true;
            this.buttonHandNumber4.Click += new System.EventHandler(this.buttonHandNumber_Click);
            // 
            // buttonHandNumber3
            // 
            this.buttonHandNumber3.Location = new System.Drawing.Point(103, 18);
            this.buttonHandNumber3.Name = "buttonHandNumber3";
            this.buttonHandNumber3.Size = new System.Drawing.Size(44, 44);
            this.buttonHandNumber3.TabIndex = 8;
            this.buttonHandNumber3.Text = "3";
            this.buttonHandNumber3.UseVisualStyleBackColor = true;
            this.buttonHandNumber3.Click += new System.EventHandler(this.buttonHandNumber_Click);
            // 
            // buttonHandNumber2
            // 
            this.buttonHandNumber2.Location = new System.Drawing.Point(53, 18);
            this.buttonHandNumber2.Name = "buttonHandNumber2";
            this.buttonHandNumber2.Size = new System.Drawing.Size(44, 44);
            this.buttonHandNumber2.TabIndex = 7;
            this.buttonHandNumber2.Text = "2";
            this.buttonHandNumber2.UseVisualStyleBackColor = true;
            this.buttonHandNumber2.Click += new System.EventHandler(this.buttonHandNumber_Click);
            // 
            // buttonHandNumber1
            // 
            this.buttonHandNumber1.Location = new System.Drawing.Point(3, 18);
            this.buttonHandNumber1.Name = "buttonHandNumber1";
            this.buttonHandNumber1.Size = new System.Drawing.Size(44, 44);
            this.buttonHandNumber1.TabIndex = 6;
            this.buttonHandNumber1.Text = "1";
            this.buttonHandNumber1.UseVisualStyleBackColor = true;
            this.buttonHandNumber1.Click += new System.EventHandler(this.buttonHandNumber_Click);
            // 
            // groupBoxHandSize
            // 
            this.groupBoxHandSize.Controls.Add(this.buttonHandSize10);
            this.groupBoxHandSize.Controls.Add(this.buttonHandSize9);
            this.groupBoxHandSize.Controls.Add(this.buttonHandSize8);
            this.groupBoxHandSize.Controls.Add(this.buttonHandSize7);
            this.groupBoxHandSize.Controls.Add(this.buttonHandSize6);
            this.groupBoxHandSize.Controls.Add(this.buttonHandSize5);
            this.groupBoxHandSize.Controls.Add(this.buttonHandSize4);
            this.groupBoxHandSize.Controls.Add(this.buttonHandSize3);
            this.groupBoxHandSize.Controls.Add(this.buttonHandSize2);
            this.groupBoxHandSize.Controls.Add(this.buttonHandSize1);
            this.groupBoxHandSize.Location = new System.Drawing.Point(19, 470);
            this.groupBoxHandSize.Name = "groupBoxHandSize";
            this.groupBoxHandSize.Size = new System.Drawing.Size(500, 70);
            this.groupBoxHandSize.TabIndex = 16;
            this.groupBoxHandSize.TabStop = false;
            this.groupBoxHandSize.Text = "Hand Size";
            // 
            // buttonHandSize10
            // 
            this.buttonHandSize10.Location = new System.Drawing.Point(453, 18);
            this.buttonHandSize10.Name = "buttonHandSize10";
            this.buttonHandSize10.Size = new System.Drawing.Size(44, 44);
            this.buttonHandSize10.TabIndex = 15;
            this.buttonHandSize10.Text = "10";
            this.buttonHandSize10.UseVisualStyleBackColor = true;
            this.buttonHandSize10.Click += new System.EventHandler(this.buttonHandSize_Click);
            // 
            // buttonHandSize9
            // 
            this.buttonHandSize9.Location = new System.Drawing.Point(403, 18);
            this.buttonHandSize9.Name = "buttonHandSize9";
            this.buttonHandSize9.Size = new System.Drawing.Size(44, 44);
            this.buttonHandSize9.TabIndex = 14;
            this.buttonHandSize9.Text = "9";
            this.buttonHandSize9.UseVisualStyleBackColor = true;
            this.buttonHandSize9.Click += new System.EventHandler(this.buttonHandSize_Click);
            // 
            // buttonHandSize8
            // 
            this.buttonHandSize8.Location = new System.Drawing.Point(353, 18);
            this.buttonHandSize8.Name = "buttonHandSize8";
            this.buttonHandSize8.Size = new System.Drawing.Size(44, 44);
            this.buttonHandSize8.TabIndex = 13;
            this.buttonHandSize8.Text = "8";
            this.buttonHandSize8.UseVisualStyleBackColor = true;
            this.buttonHandSize8.Click += new System.EventHandler(this.buttonHandSize_Click);
            // 
            // buttonHandSize7
            // 
            this.buttonHandSize7.Location = new System.Drawing.Point(303, 18);
            this.buttonHandSize7.Name = "buttonHandSize7";
            this.buttonHandSize7.Size = new System.Drawing.Size(44, 44);
            this.buttonHandSize7.TabIndex = 12;
            this.buttonHandSize7.Text = "7";
            this.buttonHandSize7.UseVisualStyleBackColor = true;
            this.buttonHandSize7.Click += new System.EventHandler(this.buttonHandSize_Click);
            // 
            // buttonHandSize6
            // 
            this.buttonHandSize6.Location = new System.Drawing.Point(253, 18);
            this.buttonHandSize6.Name = "buttonHandSize6";
            this.buttonHandSize6.Size = new System.Drawing.Size(44, 44);
            this.buttonHandSize6.TabIndex = 11;
            this.buttonHandSize6.Text = "6";
            this.buttonHandSize6.UseVisualStyleBackColor = true;
            this.buttonHandSize6.Click += new System.EventHandler(this.buttonHandSize_Click);
            // 
            // buttonHandSize5
            // 
            this.buttonHandSize5.Location = new System.Drawing.Point(203, 18);
            this.buttonHandSize5.Name = "buttonHandSize5";
            this.buttonHandSize5.Size = new System.Drawing.Size(44, 44);
            this.buttonHandSize5.TabIndex = 10;
            this.buttonHandSize5.Text = "5";
            this.buttonHandSize5.UseVisualStyleBackColor = true;
            this.buttonHandSize5.Click += new System.EventHandler(this.buttonHandSize_Click);
            // 
            // buttonHandSize4
            // 
            this.buttonHandSize4.Location = new System.Drawing.Point(153, 18);
            this.buttonHandSize4.Name = "buttonHandSize4";
            this.buttonHandSize4.Size = new System.Drawing.Size(44, 44);
            this.buttonHandSize4.TabIndex = 9;
            this.buttonHandSize4.Text = "4";
            this.buttonHandSize4.UseVisualStyleBackColor = true;
            this.buttonHandSize4.Click += new System.EventHandler(this.buttonHandSize_Click);
            // 
            // buttonHandSize3
            // 
            this.buttonHandSize3.Location = new System.Drawing.Point(103, 18);
            this.buttonHandSize3.Name = "buttonHandSize3";
            this.buttonHandSize3.Size = new System.Drawing.Size(44, 44);
            this.buttonHandSize3.TabIndex = 8;
            this.buttonHandSize3.Text = "3";
            this.buttonHandSize3.UseVisualStyleBackColor = true;
            this.buttonHandSize3.Click += new System.EventHandler(this.buttonHandSize_Click);
            // 
            // buttonHandSize2
            // 
            this.buttonHandSize2.Location = new System.Drawing.Point(53, 18);
            this.buttonHandSize2.Name = "buttonHandSize2";
            this.buttonHandSize2.Size = new System.Drawing.Size(44, 44);
            this.buttonHandSize2.TabIndex = 7;
            this.buttonHandSize2.Text = "2";
            this.buttonHandSize2.UseVisualStyleBackColor = true;
            this.buttonHandSize2.Click += new System.EventHandler(this.buttonHandSize_Click);
            // 
            // buttonHandSize1
            // 
            this.buttonHandSize1.Location = new System.Drawing.Point(3, 18);
            this.buttonHandSize1.Name = "buttonHandSize1";
            this.buttonHandSize1.Size = new System.Drawing.Size(44, 44);
            this.buttonHandSize1.TabIndex = 6;
            this.buttonHandSize1.Text = "1";
            this.buttonHandSize1.UseVisualStyleBackColor = true;
            this.buttonHandSize1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.buttonHandSize_Click);
            // 
            // groupBoxBoardSize
            // 
            this.groupBoxBoardSize.Controls.Add(this.buttonBoardSize7);
            this.groupBoxBoardSize.Controls.Add(this.buttonBoardSize6);
            this.groupBoxBoardSize.Controls.Add(this.buttonBoardSize5);
            this.groupBoxBoardSize.Controls.Add(this.buttonBoardSize4);
            this.groupBoxBoardSize.Controls.Add(this.buttonBoardSize3);
            this.groupBoxBoardSize.Controls.Add(this.buttonBoardSize2);
            this.groupBoxBoardSize.Controls.Add(this.buttonBoardSize1);
            this.groupBoxBoardSize.Location = new System.Drawing.Point(88, 276);
            this.groupBoxBoardSize.Name = "groupBoxBoardSize";
            this.groupBoxBoardSize.Size = new System.Drawing.Size(351, 70);
            this.groupBoxBoardSize.TabIndex = 7;
            this.groupBoxBoardSize.TabStop = false;
            this.groupBoxBoardSize.Text = "Board Size";
            // 
            // buttonBoardSize7
            // 
            this.buttonBoardSize7.Location = new System.Drawing.Point(303, 18);
            this.buttonBoardSize7.Name = "buttonBoardSize7";
            this.buttonBoardSize7.Size = new System.Drawing.Size(44, 44);
            this.buttonBoardSize7.TabIndex = 12;
            this.buttonBoardSize7.Text = "7";
            this.buttonBoardSize7.UseVisualStyleBackColor = true;
            this.buttonBoardSize7.Click += new System.EventHandler(this.buttonBoardSize_Click);
            // 
            // buttonBoardSize6
            // 
            this.buttonBoardSize6.Location = new System.Drawing.Point(253, 18);
            this.buttonBoardSize6.Name = "buttonBoardSize6";
            this.buttonBoardSize6.Size = new System.Drawing.Size(44, 44);
            this.buttonBoardSize6.TabIndex = 11;
            this.buttonBoardSize6.Text = "6";
            this.buttonBoardSize6.UseVisualStyleBackColor = true;
            this.buttonBoardSize6.Click += new System.EventHandler(this.buttonBoardSize_Click);
            // 
            // buttonBoardSize5
            // 
            this.buttonBoardSize5.Location = new System.Drawing.Point(203, 17);
            this.buttonBoardSize5.Name = "buttonBoardSize5";
            this.buttonBoardSize5.Size = new System.Drawing.Size(44, 44);
            this.buttonBoardSize5.TabIndex = 10;
            this.buttonBoardSize5.Text = "5";
            this.buttonBoardSize5.UseVisualStyleBackColor = true;
            this.buttonBoardSize5.Click += new System.EventHandler(this.buttonBoardSize_Click);
            // 
            // buttonBoardSize4
            // 
            this.buttonBoardSize4.Location = new System.Drawing.Point(153, 17);
            this.buttonBoardSize4.Name = "buttonBoardSize4";
            this.buttonBoardSize4.Size = new System.Drawing.Size(44, 44);
            this.buttonBoardSize4.TabIndex = 9;
            this.buttonBoardSize4.Text = "4";
            this.buttonBoardSize4.UseVisualStyleBackColor = true;
            this.buttonBoardSize4.Click += new System.EventHandler(this.buttonBoardSize_Click);
            // 
            // buttonBoardSize3
            // 
            this.buttonBoardSize3.Location = new System.Drawing.Point(103, 17);
            this.buttonBoardSize3.Name = "buttonBoardSize3";
            this.buttonBoardSize3.Size = new System.Drawing.Size(44, 44);
            this.buttonBoardSize3.TabIndex = 8;
            this.buttonBoardSize3.Text = "3";
            this.buttonBoardSize3.UseVisualStyleBackColor = true;
            this.buttonBoardSize3.Click += new System.EventHandler(this.buttonBoardSize_Click);
            // 
            // buttonBoardSize2
            // 
            this.buttonBoardSize2.Location = new System.Drawing.Point(53, 18);
            this.buttonBoardSize2.Name = "buttonBoardSize2";
            this.buttonBoardSize2.Size = new System.Drawing.Size(44, 44);
            this.buttonBoardSize2.TabIndex = 7;
            this.buttonBoardSize2.Text = "2";
            this.buttonBoardSize2.UseVisualStyleBackColor = true;
            this.buttonBoardSize2.Click += new System.EventHandler(this.buttonBoardSize_Click);
            // 
            // buttonBoardSize1
            // 
            this.buttonBoardSize1.Location = new System.Drawing.Point(3, 18);
            this.buttonBoardSize1.Name = "buttonBoardSize1";
            this.buttonBoardSize1.Size = new System.Drawing.Size(44, 44);
            this.buttonBoardSize1.TabIndex = 6;
            this.buttonBoardSize1.Text = "1";
            this.buttonBoardSize1.UseVisualStyleBackColor = true;
            this.buttonBoardSize1.Click += new System.EventHandler(this.buttonBoardSize_Click);
            // 
            // buttonHero
            // 
            this.buttonHero.Location = new System.Drawing.Point(22, 352);
            this.buttonHero.Name = "buttonHero";
            this.buttonHero.Size = new System.Drawing.Size(494, 36);
            this.buttonHero.TabIndex = 7;
            this.buttonHero.Text = "Hero";
            this.buttonHero.UseVisualStyleBackColor = true;
            this.buttonHero.MouseDown += new System.Windows.Forms.MouseEventHandler(this.buttonHero_MouseClick);
            // 
            // buttonPlay
            // 
            this.buttonPlay.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.buttonPlay.Location = new System.Drawing.Point(3, 3);
            this.buttonPlay.Name = "buttonPlay";
            this.buttonPlay.Size = new System.Drawing.Size(75, 23);
            this.buttonPlay.TabIndex = 1;
            this.buttonPlay.Text = "Play";
            this.buttonPlay.UseVisualStyleBackColor = false;
            // 
            // buttonPlayOn
            // 
            this.buttonPlayOn.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.buttonPlayOn.Location = new System.Drawing.Point(3, 32);
            this.buttonPlayOn.Name = "buttonPlayOn";
            this.buttonPlayOn.Size = new System.Drawing.Size(75, 23);
            this.buttonPlayOn.TabIndex = 2;
            this.buttonPlayOn.Text = "Play On";
            this.buttonPlayOn.UseVisualStyleBackColor = true;
            // 
            // buttonAttack
            // 
            this.buttonAttack.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.buttonAttack.Location = new System.Drawing.Point(3, 61);
            this.buttonAttack.Name = "buttonAttack";
            this.buttonAttack.Size = new System.Drawing.Size(75, 23);
            this.buttonAttack.TabIndex = 3;
            this.buttonAttack.Text = "Attack";
            this.buttonAttack.UseVisualStyleBackColor = false;
            // 
            // buttonPower
            // 
            this.buttonPower.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.buttonPower.Location = new System.Drawing.Point(3, 90);
            this.buttonPower.Name = "buttonPower";
            this.buttonPower.Size = new System.Drawing.Size(75, 23);
            this.buttonPower.TabIndex = 4;
            this.buttonPower.Text = "Power";
            this.buttonPower.UseVisualStyleBackColor = false;
            // 
            // buttonEnd
            // 
            this.buttonEnd.Location = new System.Drawing.Point(3, 119);
            this.buttonEnd.Name = "buttonEnd";
            this.buttonEnd.Size = new System.Drawing.Size(75, 23);
            this.buttonEnd.TabIndex = 5;
            this.buttonEnd.Text = "End";
            this.buttonEnd.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flowLayoutPanel1.Controls.Add(this.buttonPlay);
            this.flowLayoutPanel1.Controls.Add(this.buttonPlayOn);
            this.flowLayoutPanel1.Controls.Add(this.buttonAttack);
            this.flowLayoutPanel1.Controls.Add(this.buttonPower);
            this.flowLayoutPanel1.Controls.Add(this.buttonEnd);
            this.flowLayoutPanel1.Controls.Add(this.buttonReset);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 12);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(98, 273);
            this.flowLayoutPanel1.TabIndex = 6;
            // 
            // buttonReset
            // 
            this.buttonReset.Location = new System.Drawing.Point(3, 148);
            this.buttonReset.Name = "buttonReset";
            this.buttonReset.Size = new System.Drawing.Size(75, 23);
            this.buttonReset.TabIndex = 6;
            this.buttonReset.Text = "Reset";
            this.buttonReset.UseVisualStyleBackColor = true;
            this.buttonReset.Click += new System.EventHandler(this.buttonReset_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(5, 294);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(95, 20);
            this.textBox1.TabIndex = 7;
            // 
            // buttonConnect
            // 
            this.buttonConnect.Location = new System.Drawing.Point(12, 320);
            this.buttonConnect.Name = "buttonConnect";
            this.buttonConnect.Size = new System.Drawing.Size(75, 23);
            this.buttonConnect.TabIndex = 8;
            this.buttonConnect.Text = "Connect";
            this.buttonConnect.UseVisualStyleBackColor = true;
            this.buttonConnect.Click += new System.EventHandler(this.buttonConnect_Click);
            // 
            // HS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(648, 582);
            this.Controls.Add(this.buttonConnect);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.panel1);
            this.Name = "HS";
            this.Text = "Console";
            this.panel1.ResumeLayout(false);
            this.groupBoxBoardEnemyNumber.ResumeLayout(false);
            this.groupBoxBoardEnemySize.ResumeLayout(false);
            this.groupBoxBoardNumber.ResumeLayout(false);
            this.groupBoxHandNumber.ResumeLayout(false);
            this.groupBoxHandSize.ResumeLayout(false);
            this.groupBoxBoardSize.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button buttonPlay;
        private System.Windows.Forms.Button buttonPlayOn;
        private System.Windows.Forms.Button buttonAttack;
        private System.Windows.Forms.Button buttonPower;
        private System.Windows.Forms.Button buttonEnd;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.GroupBox groupBoxBoardSize;
        private System.Windows.Forms.Button buttonBoardSize2;
        private System.Windows.Forms.Button buttonBoardSize1;
        private System.Windows.Forms.Button buttonBoardSize7;
        private System.Windows.Forms.Button buttonBoardSize6;
        private System.Windows.Forms.Button buttonBoardSize5;
        private System.Windows.Forms.Button buttonBoardSize4;
        private System.Windows.Forms.Button buttonBoardSize3;
        private System.Windows.Forms.GroupBox groupBoxHandSize;
        private System.Windows.Forms.Button buttonHandSize10;
        private System.Windows.Forms.Button buttonHandSize9;
        private System.Windows.Forms.Button buttonHandSize8;
        private System.Windows.Forms.Button buttonHandSize7;
        private System.Windows.Forms.Button buttonHandSize6;
        private System.Windows.Forms.Button buttonHandSize4;
        private System.Windows.Forms.Button buttonHandSize3;
        private System.Windows.Forms.Button buttonHandSize2;
        private System.Windows.Forms.Button buttonHandSize1;
        private System.Windows.Forms.Button buttonReset;
        private System.Windows.Forms.Button buttonHandSize5;
        private System.Windows.Forms.GroupBox groupBoxHandNumber;
        private System.Windows.Forms.Button buttonHandNumber10;
        private System.Windows.Forms.Button buttonHandNumber9;
        private System.Windows.Forms.Button buttonHandNumber8;
        private System.Windows.Forms.Button buttonHandNumber7;
        private System.Windows.Forms.Button buttonHandNumber6;
        private System.Windows.Forms.Button buttonHandNumber5;
        private System.Windows.Forms.Button buttonHandNumber4;
        private System.Windows.Forms.Button buttonHandNumber3;
        private System.Windows.Forms.Button buttonHandNumber2;
        private System.Windows.Forms.Button buttonHandNumber1;
        private System.Windows.Forms.Button buttonHero;
        private System.Windows.Forms.GroupBox groupBoxBoardEnemySize;
        private System.Windows.Forms.Button buttonBoardEnemySize7;
        private System.Windows.Forms.Button buttonBoardEnemySize6;
        private System.Windows.Forms.Button buttonBoardEnemySize5;
        private System.Windows.Forms.Button buttonBoardEnemySize4;
        private System.Windows.Forms.Button buttonBoardEnemySize3;
        private System.Windows.Forms.Button buttonBoardEnemySize2;
        private System.Windows.Forms.Button buttonBoardEnemySize1;
        private System.Windows.Forms.GroupBox groupBoxBoardNumber;
        private System.Windows.Forms.Button buttonBoardNumber7;
        private System.Windows.Forms.Button buttonBoardNumber6;
        private System.Windows.Forms.Button buttonBoardNumber5;
        private System.Windows.Forms.Button buttonBoardNumber4;
        private System.Windows.Forms.Button buttonBoardNumber3;
        private System.Windows.Forms.Button buttonBoardNumber2;
        private System.Windows.Forms.Button buttonBoardNumber1;
        private System.Windows.Forms.Button buttonHeroEnemy;
        private System.Windows.Forms.GroupBox groupBoxBoardEnemyNumber;
        private System.Windows.Forms.Button buttonBoardEnemyNumber7;
        private System.Windows.Forms.Button buttonBoardEnemyNumber6;
        private System.Windows.Forms.Button buttonBoardEnemyNumber5;
        private System.Windows.Forms.Button buttonBoardEnemyNumber4;
        private System.Windows.Forms.Button buttonBoardEnemyNumber3;
        private System.Windows.Forms.Button buttonBoardEnemyNumber2;
        private System.Windows.Forms.Button buttonBoardEnemyNumber1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button buttonConnect;
    }
}